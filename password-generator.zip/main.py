#basic password generator
#https://github.com/dontmindslq

#Find the passwords that u generated in passwords.log !

print ("")

from art import *
my_art = text2art("PASSWORD GENERATOR", font='bulbhead')

print(my_art)

import random
import string
import logging

def generate_password(length):
    characters = string.ascii_letters + string.digits + string.punctuation
    password = ''.join(random.choice(characters) for _ in range(length))
    return password

password_length = 24

password = generate_password(password_length)

password = generate_password(password_length)

logger = logging.getLogger('password_generator')
logger.setLevel(logging.INFO)

file_handler = logging.FileHandler('passwords.log')
file_handler.setFormatter(logging.Formatter('%(asctime)s - %(message)s'))

logger.addHandler(file_handler)

logger.info(password)


print ("")
print("Password generated:", password)
print("")
print("Find the passwords that u generated in passwords.log")
print ("")
print ("Check out more of my github: https://github.com/dontmindslq")
print ("")
